package com.salati.prayer;
import android.app.*;import android.appwidget.*;import android.content.*;import android.graphics.Color;import android.os.Bundle;import android.widget.RemoteViews;import org.json.*;import java.text.*;import java.util.*;
public final class PrayerWidget extends AppWidgetProvider{
 static final String ACTION="com.salati.prayer.WIDGET_REFRESH";
 static final String ACTION_RECOVER="com.salati.prayer.WIDGET_RECOVER";
 static final long RECOVERY_INTERVAL=15*60*1000L;
 static String clock(long time,String zone){SimpleDateFormat f=new SimpleDateFormat("h:mm",Locale.US);f.setTimeZone(TimeZone.getTimeZone(zone));return f.format(new Date(time));}
 static String day(long now,String zone){SimpleDateFormat f=new SimpleDateFormat("yyyy-MM-dd",Locale.US);f.setTimeZone(TimeZone.getTimeZone(zone));return f.format(new Date(now));}
 static void updateAll(Context c){AppWidgetManager m=AppWidgetManager.getInstance(c);int[] ids=m.getAppWidgetIds(new ComponentName(c,PrayerWidget.class));for(int id:ids)update(c,m,id);if(ids.length>0)schedule(c);}
 static void update(Context c,AppWidgetManager manager,int id){RemoteViews views=new RemoteViews(c.getPackageName(),R.layout.prayer_widget);JSONObject config=PrayerSchedule.config(c);String zone=config.optString("zone",TimeZone.getDefault().getID());long now=System.currentTimeMillis();String today=day(now,zone);JSONArray days=config.optJSONArray("days");JSONObject found=null;JSONObject nextDay=null;if(days!=null)for(int i=0;i<days.length();i++){JSONObject d=days.optJSONObject(i);if(d==null)continue;if(today.equals(d.optString("date")))found=d;else if(d.optString("date").compareTo(today)>0&&(nextDay==null||d.optString("date").compareTo(nextDay.optString("date"))<0))nextDay=d;}

 boolean daylight=WidgetAppearancePolicy.isDay(now,zone,found==null?0:found.optLong("sunrise"),found==null?0:found.optLong("maghrib"));views.setImageViewResource(R.id.widget_scenery,daylight?R.drawable.widget_mosque_day:R.drawable.widget_mosque_night);views.setImageViewResource(R.id.widget_overlay,daylight?R.drawable.widget_overlay_day:R.drawable.widget_overlay_night);int primary=Color.WHITE,secondary=Color.WHITE;int[] primaryIds={R.id.widget_next,R.id.widget_countdown,R.id.widget_fajr,R.id.widget_sunrise,R.id.widget_dhuhr,R.id.widget_asr,R.id.widget_maghrib,R.id.widget_isha};for(int textId:primaryIds)views.setTextColor(textId,primary);int[] secondaryIds={R.id.widget_next_label,R.id.widget_countdown_label,R.id.widget_label_fajr,R.id.widget_label_sunrise,R.id.widget_label_dhuhr,R.id.widget_label_asr,R.id.widget_label_maghrib,R.id.widget_label_isha};for(int textId:secondaryIds)views.setTextColor(textId,secondary);Bundle size=manager.getAppWidgetOptions(id);int height=size.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT,110);boolean compact=height<105;int inset=Math.round((compact?6:10)*c.getResources().getDisplayMetrics().density);views.setViewPadding(R.id.widget_card,inset,inset,inset,inset);views.setViewVisibility(R.id.widget_next_label,compact?android.view.View.GONE:android.view.View.VISIBLE);views.setViewVisibility(R.id.widget_countdown_label,compact?android.view.View.GONE:android.view.View.VISIBLE);
 String[] keys={"fajr","sunrise","dhuhr","asr","maghrib","isha"};int[] valueIds={R.id.widget_fajr,R.id.widget_sunrise,R.id.widget_dhuhr,R.id.widget_asr,R.id.widget_maghrib,R.id.widget_isha};for(int i=0;i<6;i++)views.setTextViewText(valueIds[i],found!=null&&found.optLong(keys[i])>0?clock(found.optLong(keys[i]),zone):"—");String upcomingKey="";String next="—";long nextTime=0;if(found!=null){for(String key:keys)if(!"sunrise".equals(key)&&found.optLong(key)>now){upcomingKey=key;next=AdhanService.prayerName(key);nextTime=found.optLong(key);break;}if(upcomingKey.isEmpty()&&nextDay!=null){upcomingKey="fajr";next="الفجر";nextTime=nextDay.optLong("fajr");}}views.setViewVisibility(R.id.widget_countdown_row,nextTime>now?android.view.View.VISIBLE:android.view.View.GONE);views.setChronometerCountDown(R.id.widget_countdown,true);views.setChronometer(R.id.widget_countdown,android.os.SystemClock.elapsedRealtime()+Math.max(0,nextTime-now),null,nextTime>now);views.setTextViewText(R.id.widget_next,next);views.setTextViewText(R.id.widget_next_label,upcomingKey.isEmpty()?"افتح صلاتي لتحديث المواقيت":"الصلاة القادمة");int[] cellIds={R.id.widget_cell_fajr,R.id.widget_cell_sunrise,R.id.widget_cell_dhuhr,R.id.widget_cell_asr,R.id.widget_cell_maghrib,R.id.widget_cell_isha};for(int n=0;n<keys.length;n++)views.setInt(cellIds[n],"setBackgroundResource",keys[n].equals(upcomingKey)?R.drawable.widget_prayer_active:0);
 PendingIntent open=PendingIntent.getActivity(c,90,new Intent(c,MainActivity.class),PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);views.setOnClickPendingIntent(R.id.widget_root,open);manager.updateAppWidget(id,views);}
 static PendingIntent refreshIntent(Context c,int requestCode,String action){
  return PendingIntent.getBroadcast(c,requestCode,new Intent(c,PrayerWidget.class).setAction(action),PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
 }
 static void schedule(Context c){
  AlarmManager alarm=c.getSystemService(AlarmManager.class);
  if(alarm==null)return;
  JSONObject config=PrayerSchedule.config(c);
  String zone=config.optString("zone",TimeZone.getDefault().getID());
  long now=System.currentTimeMillis();
  JSONArray days=config.optJSONArray("days");
  JSONObject current=null;
  ArrayList<Long> events=new ArrayList<>();
  if(days!=null)for(int n=0;n<days.length();n++){
   JSONObject d=days.optJSONObject(n);if(d==null)continue;
   if(day(now,zone).equals(d.optString("date")))current=d;
   for(String key:new String[]{"fajr","sunrise","dhuhr","asr","maghrib","isha"})events.add(d.optLong(key));
  }
  long[] prayerTimes=new long[events.size()];for(int n=0;n<events.size();n++)prayerTimes[n]=events.get(n);
  long when=WidgetAppearancePolicy.nextRefresh(now,zone,current==null?0:current.optLong("sunrise"),current==null?0:current.optLong("maghrib"),prayerTimes);
  PendingIntent boundary=refreshIntent(c,91,ACTION);
  try{
   if(PrayerSchedule.exactAlarmsAllowed(c))alarm.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,when,boundary);
   else alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,when,boundary);
  }catch(SecurityException denied){
   // Permission can be revoked between the capability check and scheduling.
   alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,when,boundary);
  }
  // Independent recovery survives a late/missed boundary delivery. Each delivery
  // recomputes appearance and next prayer from the current instant, never equality.
  alarm.setInexactRepeating(AlarmManager.RTC_WAKEUP,now+RECOVERY_INTERVAL,RECOVERY_INTERVAL,refreshIntent(c,92,ACTION_RECOVER));
 }
 @Override public void onUpdate(Context c,AppWidgetManager m,int[] ids){updateAll(c);}
 @Override public void onReceive(Context c,Intent i){super.onReceive(c,i);if(ACTION.equals(i.getAction())||ACTION_RECOVER.equals(i.getAction())||Intent.ACTION_DATE_CHANGED.equals(i.getAction()))updateAll(c);}
 @Override public void onAppWidgetOptionsChanged(Context c,AppWidgetManager m,int id,Bundle options){updateAll(c);}
 @Override public void onDisabled(Context c){
  AlarmManager alarm=c.getSystemService(AlarmManager.class);
  for(int code:new int[]{91,92}){
   PendingIntent pending=refreshIntent(c,code,code==91?ACTION:ACTION_RECOVER);
   if(alarm!=null)alarm.cancel(pending);pending.cancel();
  }
 }
}
